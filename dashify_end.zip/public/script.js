$('.scroll-me').slimScroll({
		height: '250px',
    width: '300px',
		color: "#EEE"
	});