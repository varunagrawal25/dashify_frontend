import React, { Component } from 'react'

export default class Aboutus extends Component {
    componentDidMount() {
        window.scrollTo(0, 0)
    }
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
