export const all_connection_of_one_location_json = {
  Listing_details: {
    all_listing: "23",
    live_listing: "12",
    processing: "4",
    unavailable: "6",
    opted_out: "1"
  },
  data: [
    { Social_Platform: { Platform: "Facebook" } },
    { Social_Platform: { Platform: "Google" } },
    { Social_Platform: { Platform: "Tomtom" } },
    { Social_Platform: { Platform: "Yelp" } },
    { Social_Platform: { Platform: "Avvo" } },
    { Social_Platform: { Platform: "Citysearch" } }
  ]
};
